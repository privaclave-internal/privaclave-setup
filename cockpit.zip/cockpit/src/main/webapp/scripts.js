// table row dropdown

$(document).ready(function () {

  // sodebar toggle functionality
  $('.toggle-btn').on('click', function () {
    $('.sidebar').toggleClass('collapsed');
  });

  //table array data for dashboard



  //table array data for Policy Handlers
  var policyHandlerstableData = [
    {
      "policyHandlerId": "AGNTB268A4A2",
      "policyHandlerName": "HealthSystem",
      "path": "https://privaclave.top:8443/CockpitAgent",
      "status": "HANDSHAKED",
      "updateInterval": "2 Hrs",
      "autoPilots": "1 AutoPilots",
    },
    {
      "policyHandlerId": "AGNTB268A4A2",
      "policyHandlerName": "HealthSystem",
      "path": "https://privaclave.top:8443/CockpitAgent",
      "status": "HANDSHAKED",
      "updateInterval": "2 Hrs",
      "autoPilots": "1 AutoPilots",
    },
    {
      "policyHandlerId": "AGNTB268A4A2",
      "policyHandlerName": "HealthSystem",
      "path": "https://privaclave.top:8443/CockpitAgent",
      "status": "HANDSHAKED",
      "updateInterval": "2 Hrs",
      "autoPilots": "1 AutoPilots",
    },
    {
      "policyHandlerId": "AGNTB268A4A2",
      "policyHandlerName": "HealthSystem",
      "path": "https://privaclave.top:8443/CockpitAgent",
      "status": "HANDSHAKED",
      "updateInterval": "2 Hrs",
      "autoPilots": "1 AutoPilots",
    },
    {
      "policyHandlerId": "AGNTB268A4A2",
      "policyHandlerName": "HealthSystem",
      "path": "https://privaclave.top:8443/CockpitAgent",
      "status": "HANDSHAKED",
      "updateInterval": "2 Hrs",
      "autoPilots": "1 AutoPilots",
    },
    {
      "policyHandlerId": "AGNTB268A4A2",
      "policyHandlerName": "HealthSystem",
      "path": "https://privaclave.top:8443/CockpitAgent",
      "status": "HANDSHAKED",
      "updateInterval": "2 Hrs",
      "autoPilots": "1 AutoPilots",
    }
  ];



  // Render Policy Handlers Table
  var $tbody = $('.policy_handlers_data');
  $tbody.empty();
  policyHandlerstableData.forEach(function (row) {
    var $tr = $('<tr>');
    $tr.append($('<td>').text(row.policyHandlerId));
    $tr.append($('<td>').text(row.policyHandlerName));
    $tr.append($('<td>').text(row.path));
    $tr.append($('<td>').text(row.status));
    $tr.append($('<td>').text(row.updateInterval));
    $tr.append($('<td>').text(row.autoPilots));
    $tr.append(
      //<i class="fa fa-edit edit-icon" style="cursor:pointer; margin-right:10px;" title="Edit"></i>
      //<i class="fa fa-trash delete-icon" style="cursor:pointer; margin-right:10px; color:#d9534f;" title="Delete"></i>
      $('<td>').html(`
   <div class="action_icon">     
<span class="edit-icon" style="margin-bottom: -3px; cursor:pointer; margin-right:10px;" title="Edit"><svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M5.375 19H6.8L16.575 9.225L15.15 7.8L5.375 17.575V19ZM3.375 21V16.75L16.575 3.575C16.775 3.39167 16.9958 3.25 17.2375 3.15C17.4792 3.05 17.7333 3 18 3C18.2667 3 18.525 3.05 18.775 3.15C19.025 3.25 19.2417 3.4 19.425 3.6L20.8 5C21 5.18333 21.1458 5.4 21.2375 5.65C21.3292 5.9 21.375 6.15 21.375 6.4C21.375 6.66667 21.3292 6.92083 21.2375 7.1625C21.1458 7.40417 21 7.625 20.8 7.825L7.625 21H3.375ZM15.85 8.525L15.15 7.8L16.575 9.225L15.85 8.525Z" fill="#8D2BBC"/>
</svg></span>    
<span class="delete-icon" style="margin-bottom: -3px; cursor:pointer; margin-right:10px; title="Delete"><svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M7.375 21C6.825 21 6.35417 20.8042 5.9625 20.4125C5.57083 20.0208 5.375 19.55 5.375 19V6H4.375V4H9.375V3H15.375V4H20.375V6H19.375V19C19.375 19.55 19.1792 20.0208 18.7875 20.4125C18.3958 20.8042 17.925 21 17.375 21H7.375ZM17.375 6H7.375V19H17.375V6ZM9.375 17H11.375V8H9.375V17ZM13.375 17H15.375V8H13.375V17Z" fill="#BC2B3C"/>
</svg>
</span>  
      
      <button type="button" class="btn_primary policyHandlers_button map-autopilot-btn">Map Autopilot</button>
      </div>
    `)
    );
    $tbody.append($tr);
  });

  // Handle Edit Modal
  $tbody.on('click', '.edit-icon', function () {
    var $row = $(this).closest('tr');
    var policyHandlerId = $row.find('td:nth-child(1)').text();
    var policyHandlerName = $row.find('td:nth-child(2)').text();
    var path = $row.find('td:nth-child(3)').text();
    var status = $row.find('td:nth-child(4)').text();
    var updateInterval = $row.find('td:nth-child(5)').text();
    var autoPilots = $row.find('td:nth-child(6)').text();

    $('#editPolicyHandlerId').val(policyHandlerId);
    $('#editPolicyHandlerName').val(policyHandlerName);
    $('#editPath').val(path);
    $('#editStatus').val(status);
    $('#editUpdateInterval').val(updateInterval);
    $('#editAutoPilots').val(autoPilots);

    $('#editPolicyHandlerModal').fadeIn();
  });

  $tbody.on('click', '.delete-icon', function () {
    var $row = $(this).closest('tr');
    var policyHandlerName = $row.find('td:nth-child(2)').text();

    $('#deletePolicyHandlerName').text(policyHandlerName);

    // Show the Delete Modal
    $('#deletePolicyHandlerModal').fadeIn();
  });

  $('.modal-close').on('click', function () {
    $(this).closest('.modal').fadeOut();
  });

  $(window).on('click', function (e) {
    if ($(e.target).hasClass('modal')) {
      $(e.target).fadeOut();
    }
  });

  // Add this after the table rendering code
  $tbody.on('click', '.map-autopilot-btn', function () {
    window.location.href = 'mapAutopilots.html';
  });




  //table array data for Map Autopilots
  var mapAutopilotstableData = [
    {
      "autopilotId": "AUPFB11AEFA",
      "autopilotName": "HealthSystem",
      "mode": "To Intercept Application URL Data for nLearn",
      "policyInfo": "Policy configured for 10 URL	",
    },
    {
      "autopilotId": "AUPFB11AEFA",
      "autopilotName": "HealthSystem",
      "mode": "To Intercept Application URL Data for nLearn",
      "policyInfo": "Policy configured for 10 URL	",
    },
  ];

  // Render Autopilots Table
  var $tbody = $('.autopilots_table_data');
  $tbody.empty();
  mapAutopilotstableData.forEach(function (row) {
    var $tr = $('<tr>');
    $tr.append($('<td>').text(row.autopilotId));
    $tr.append($('<td>').text(row.autopilotName));
    $tr.append($('<td>').text(row.mode));
    $tr.append($('<td>').text(row.policyInfo));
    $tr.append(
      // <i class="fa fa-edit edit-icon" style="cursor:pointer; margin-right:10px;" title="Edit"></i>
      // <i class="fa fa-trash delete-icon" style="cursor:pointer; margin-right:10px; color:#d9534f;" title="Delete"></i>
      // <button type="button" class="btn_primary policyHandlers_button manage-url-policy-btn">Manage URL Policy</button>
      $('<td>').html(`      

      <div class="action_icon">     
<span class="edit-icon" style="margin-bottom: -3px; cursor:pointer; margin-right:10px;" title="Edit"><svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M5.375 19H6.8L16.575 9.225L15.15 7.8L5.375 17.575V19ZM3.375 21V16.75L16.575 3.575C16.775 3.39167 16.9958 3.25 17.2375 3.15C17.4792 3.05 17.7333 3 18 3C18.2667 3 18.525 3.05 18.775 3.15C19.025 3.25 19.2417 3.4 19.425 3.6L20.8 5C21 5.18333 21.1458 5.4 21.2375 5.65C21.3292 5.9 21.375 6.15 21.375 6.4C21.375 6.66667 21.3292 6.92083 21.2375 7.1625C21.1458 7.40417 21 7.625 20.8 7.825L7.625 21H3.375ZM15.85 8.525L15.15 7.8L16.575 9.225L15.85 8.525Z" fill="#8D2BBC"/>
</svg></span>    
<span class="delete-icon" style="margin-bottom: -3px; cursor:pointer; margin-right:10px; title="Delete"><svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M7.375 21C6.825 21 6.35417 20.8042 5.9625 20.4125C5.57083 20.0208 5.375 19.55 5.375 19V6H4.375V4H9.375V3H15.375V4H20.375V6H19.375V19C19.375 19.55 19.1792 20.0208 18.7875 20.4125C18.3958 20.8042 17.925 21 17.375 21H7.375ZM17.375 6H7.375V19H17.375V6ZM9.375 17H11.375V8H9.375V17ZM13.375 17H15.375V8H13.375V17Z" fill="#BC2B3C"/>
</svg>
</span>  
      
      <button type="button" class="btn_primary policyHandlers_button manage-url-policy-btn">Manage URL Policy</button>
      </div>
    `)
    );
    $tbody.append($tr);
  });

  // Handle Edit Modal
  $tbody.on('click', '.edit-icon', function () {
    var $row = $(this).closest('tr');
    var autopilotId = $row.find('td:nth-child(1)').text();
    var autopilotName = $row.find('td:nth-child(2)').text();
    var mode = $row.find('td:nth-child(3)').text();
    var policyInfo = $row.find('td:nth-child(4)').text();

    $('#editAutopilotId').val(autopilotId);
    $('#editAutopilotName').val(autopilotName);
    $('#editMode').val(mode);
    $('#editPolicyInfo').val(policyInfo);

    $('#editAutopilotModal').fadeIn();
  });

  // Handle Delete Modal
  $tbody.on('click', '.delete-icon', function () {
    var $row = $(this).closest('tr');
    var autopilotName = $row.find('td:nth-child(2)').text();
    $('#deleteAutopilotName').text(autopilotName);

    $('#deleteAutopilotModal').fadeIn();
  });
  $('.modal-close').on('click', function () {
    $(this).closest('.modal').fadeOut();
  });
  $(window).on('click', function (e) {
    if ($(e.target).hasClass('modal')) {
      $(e.target).fadeOut();
    }
  });

  // Add this after the table rendering code
  $tbody.on('click', '.manage-url-policy-btn', function () {
    window.location.href = 'manageInterceptionPolicy.html';
  });



  //table array data for manage_interception_policy_table"
  var manageInterceptionPolicyData = [
    {
      "policyHandlerId": "PL_00114",
      "policyURL": "Healthsystems/PatientRegisteration",
      "requestType": "POST_FORM",
      "interceptionInfo": [
        "Policy Applied and Interception Configured",
        "Policy Pushed to Policy Handler"
      ],
      "action": [
        "edit",
        "delete",
        "ADD JSON",
        "Compose Policy"
      ],
    },
    {
      "policyHandlerId": "AUPFB11AEFA",
      "policyURL": "HealthSystem",
      "requestType": "To Intercept Application URL Data for nLearn",
      "interceptionInfo": [
        "Policy Applied and Interception Configured",
        "Policy Pushed to Policy Handler"
      ],
      "action": [
        "ADD JSON",
        "Compose Policy"
      ],
    },
    {
      "policyHandlerId": "AUPFB11AEFA",
      "policyURL": "HealthSystem",
      "requestType": "To Intercept Application URL Data for nLearn",
      "interceptionInfo": [
        "Policy Applied and Interception Configured",
        "Policy Pushed to Policy Handler"
      ],
      "action": [

        "Configure Form",
        "Compose Policy"
      ],
    },
    {
      "policyHandlerId": "AUPFB11AEFA",
      "policyURL": "HealthSystem",
      "requestType": "To Intercept Application URL Data for nLearn",
      "interceptionInfo": [
        "Policy Applied and Interception Configured",
        "Policy Pushed to Policy Handler"
      ],
      "action": [
        "Configure Unwrap Policy",
        "On Boarding Info"
      ],
    },
    {
      "policyHandlerId": "AUPFB11AEFA",
      "policyURL": "HealthSystem",
      "requestType": "To Intercept Application URL Data for nLearn",
      "interceptionInfo": [
        "Policy Applied and Interception Configured",
        "Policy Pushed to Policy Handler"
      ],
      "action": [
        "Configure Form",
        "Compose Policy"
      ],
    },
    {
      "policyHandlerId": "AUPFB11AEFA",
      "policyURL": "HealthSystem",
      "requestType": "To Intercept Application URL Data for nLearn",
      "interceptionInfo": [
        "Policy Applied and Interception Configured",
        "Policy Pushed to Policy Handler"
      ],
      "action": [
        "Configure Unwrap Policy"

      ],
    },
  ];

  $(document).ready(function () {
    // Render Interception Policy Table
    var $tbody = $('.manage_interception_data');
    $tbody.empty();
    manageInterceptionPolicyData.forEach(function (row) {
      var $tr = $('<tr>');
      $tr.append($('<td>').text(row.policyHandlerId));
      $tr.append($('<td>').text(row.policyURL));
      $tr.append($('<td>').text(row.requestType));

      var infoBtns = row.interceptionInfo.map(function (info) {
        return `<button type="button" class="btn_primary_info interception-info-btn" style="margin:2px 4px 2px 0;">${info}</button>`;
      }).join('');
      $tr.append($('<td>').html(infoBtns));

      var actionBtns = row.action.map(function (act) {
        var buttonHTML = '';
        if (act === "Configure Unwrap Policy") {
          buttonHTML = `<span class="pop_data xbtn_outline_act configure-unwrap-btn" style="cursor: pointer;"><span class="popup_action_icon"><svg width="16" height="12" viewBox="0 0 16 12" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M5 6V4.5H3.5V6H5ZM7.025 6C7.1625 5.7125 7.32188 5.44375 7.50313 5.19375C7.68438 4.94375 7.8875 4.7125 8.1125 4.5H6.5V6H7.025ZM6.575 9C6.55 8.875 6.53438 8.75313 6.52813 8.63437C6.52188 8.51562 6.51875 8.3875 6.51875 8.25C6.51875 8.1125 6.52188 7.98438 6.52813 7.86563C6.53438 7.74688 6.55 7.625 6.575 7.5H3.5V9H6.575ZM8.09375 12H2C1.5875 12 1.23438 11.8531 0.940625 11.5594C0.646875 11.2656 0.5 10.9125 0.5 10.5V1.5C0.5 1.0875 0.646875 0.734375 0.940625 0.440625C1.23438 0.146875 1.5875 0 2 0H14C14.4125 0 14.7656 0.146875 15.0594 0.440625C15.3531 0.734375 15.5 1.0875 15.5 1.5V4.6125C15.2875 4.3875 15.0563 4.18438 14.8063 4.00313C14.5563 3.82188 14.2875 3.6625 14 3.525V1.5H2V10.5H7.025C7.1625 10.7875 7.31875 11.0562 7.49375 11.3062C7.66875 11.5562 7.86875 11.7875 8.09375 12ZM12.5 12H11L10.775 10.875C10.625 10.8125 10.4844 10.7469 10.3531 10.6781C10.2219 10.6094 10.0875 10.525 9.95 10.425L8.8625 10.7625L8.1125 9.4875L8.975 8.7375C8.95 8.575 8.9375 8.4125 8.9375 8.25C8.9375 8.0875 8.95 7.925 8.975 7.7625L8.1125 7.0125L8.8625 5.7375L9.95 6.075C10.0875 5.975 10.2219 5.89062 10.3531 5.82188C10.4844 5.75313 10.625 5.6875 10.775 5.625L11 4.5H12.5L12.725 5.625C12.875 5.6875 13.0188 5.75938 13.1562 5.84062C13.2937 5.92188 13.425 6.0125 13.55 6.1125L14.6375 5.7375L15.3875 7.05L14.525 7.8C14.55 7.9625 14.5625 8.11875 14.5625 8.26875C14.5625 8.41875 14.55 8.575 14.525 8.7375L15.3875 9.4875L14.6375 10.7625L13.55 10.425C13.4125 10.525 13.2781 10.6094 13.1469 10.6781C13.0156 10.7469 12.875 10.8125 12.725 10.875L12.5 12ZM11.75 9.75C12.1625 9.75 12.5156 9.60313 12.8094 9.30938C13.1031 9.01562 13.25 8.6625 13.25 8.25C13.25 7.8375 13.1031 7.48438 12.8094 7.19063C12.5156 6.89688 12.1625 6.75 11.75 6.75C11.3375 6.75 10.9844 6.89688 10.6906 7.19063C10.3969 7.48438 10.25 7.8375 10.25 8.25C10.25 8.6625 10.3969 9.01562 10.6906 9.30938C10.9844 9.60313 11.3375 9.75 11.75 9.75Z" fill="#484848"/>
              </svg></span>
              ${act}</span>`;
        } else if (act === "On Boarding Info") {
          buttonHTML = `<span class="pop_data xbtn_outline_act allow-re-run-btn" style="cursor: pointer; "><span class="popup_action_icon"><svg width="18" height="12" viewBox="0 0 18 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M0.75 12V9.9C0.75 9.475 0.859375 9.08437 1.07812 8.72812C1.29688 8.37187 1.5875 8.1 1.95 7.9125C2.725 7.525 3.5125 7.23438 4.3125 7.04062C5.1125 6.84687 5.925 6.75 6.75 6.75C7.575 6.75 8.3875 6.84687 9.1875 7.04062C9.9875 7.23438 10.775 7.525 11.55 7.9125C11.9125 8.1 12.2031 8.37187 12.4219 8.72812C12.6406 9.08437 12.75 9.475 12.75 9.9V12H0.75ZM14.25 12V9.75C14.25 9.2 14.0969 8.67188 13.7906 8.16562C13.4844 7.65937 13.05 7.225 12.4875 6.8625C13.125 6.9375 13.725 7.06563 14.2875 7.24688C14.85 7.42813 15.375 7.65 15.8625 7.9125C16.3125 8.1625 16.6562 8.44063 16.8937 8.74688C17.1313 9.05313 17.25 9.3875 17.25 9.75V12H14.25ZM6.75 6C5.925 6 5.21875 5.70625 4.63125 5.11875C4.04375 4.53125 3.75 3.825 3.75 3C3.75 2.175 4.04375 1.46875 4.63125 0.88125C5.21875 0.29375 5.925 0 6.75 0C7.575 0 8.28125 0.29375 8.86875 0.88125C9.45625 1.46875 9.75 2.175 9.75 3C9.75 3.825 9.45625 4.53125 8.86875 5.11875C8.28125 5.70625 7.575 6 6.75 6ZM14.25 3C14.25 3.825 13.9563 4.53125 13.3688 5.11875C12.7813 5.70625 12.075 6 11.25 6C11.1125 6 10.9375 5.98438 10.725 5.95312C10.5125 5.92188 10.3375 5.8875 10.2 5.85C10.5375 5.45 10.7969 5.00625 10.9781 4.51875C11.1594 4.03125 11.25 3.525 11.25 3C11.25 2.475 11.1594 1.96875 10.9781 1.48125C10.7969 0.99375 10.5375 0.55 10.2 0.15C10.375 0.0875 10.55 0.046875 10.725 0.028125C10.9 0.009375 11.075 0 11.25 0C12.075 0 12.7813 0.29375 13.3688 0.88125C13.9563 1.46875 14.25 2.175 14.25 3ZM2.25 10.5H11.25V9.9C11.25 9.7625 11.2156 9.6375 11.1469 9.525C11.0781 9.4125 10.9875 9.325 10.875 9.2625C10.2 8.925 9.51875 8.67188 8.83125 8.50313C8.14375 8.33438 7.45 8.25 6.75 8.25C6.05 8.25 5.35625 8.33438 4.66875 8.50313C3.98125 8.67188 3.3 8.925 2.625 9.2625C2.5125 9.325 2.42188 9.4125 2.35313 9.525C2.28438 9.6375 2.25 9.7625 2.25 9.9V10.5ZM6.75 4.5C7.1625 4.5 7.51563 4.35313 7.80938 4.05937C8.10313 3.76562 8.25 3.4125 8.25 3C8.25 2.5875 8.10313 2.23438 7.80938 1.94063C7.51563 1.64688 7.1625 1.5 6.75 1.5C6.3375 1.5 5.98438 1.64688 5.69063 1.94063C5.39687 2.23438 5.25 2.5875 5.25 3C5.25 3.4125 5.39687 3.76562 5.69063 4.05937C5.98438 4.35313 6.3375 4.5 6.75 4.5Z" fill="#484848"/>
                </svg></span> ${act}</span>`;
        } else if (act === "Configure Form") {
          buttonHTML = `<span class="pop_data configure-form-btn act_data" style="cursor: pointer; "><span class="popup_action_icon"><svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M7 5.5H10.75V4H7V5.5ZM7 10H10.75V8.5H7V10ZM4.75 6.25C5.1625 6.25 5.51562 6.10313 5.80937 5.80937C6.10313 5.51562 6.25 5.1625 6.25 4.75C6.25 4.3375 6.10313 3.98438 5.80937 3.69063C5.51562 3.39688 5.1625 3.25 4.75 3.25C4.3375 3.25 3.98438 3.39688 3.69063 3.69063C3.39688 3.98438 3.25 4.3375 3.25 4.75C3.25 5.1625 3.39688 5.51562 3.69063 5.80937C3.98438 6.10313 4.3375 6.25 4.75 6.25ZM4.75 10.75C5.1625 10.75 5.51562 10.6031 5.80937 10.3094C6.10313 10.0156 6.25 9.6625 6.25 9.25C6.25 8.8375 6.10313 8.48438 5.80937 8.19063C5.51562 7.89688 5.1625 7.75 4.75 7.75C4.3375 7.75 3.98438 7.89688 3.69063 8.19063C3.39688 8.48438 3.25 8.8375 3.25 9.25C3.25 9.6625 3.39688 10.0156 3.69063 10.3094C3.98438 10.6031 4.3375 10.75 4.75 10.75ZM1.75 13.75C1.3375 13.75 0.984375 13.6031 0.690625 13.3094C0.396875 13.0156 0.25 12.6625 0.25 12.25V1.75C0.25 1.3375 0.396875 0.984375 0.690625 0.690625C0.984375 0.396875 1.3375 0.25 1.75 0.25H12.25C12.6625 0.25 13.0156 0.396875 13.3094 0.690625C13.6031 0.984375 13.75 1.3375 13.75 1.75V12.25C13.75 12.6625 13.6031 13.0156 13.3094 13.3094C13.0156 13.6031 12.6625 13.75 12.25 13.75H1.75ZM1.75 12.25H12.25V1.75H1.75V12.25Z" fill="#484848"/>
            </svg></span> ${act}</span>`;
        } else if (act === "Compose Policy") {
          buttonHTML = `<span class="pop_data xbtn_outline_act compose-policy-btn" style="cursor: pointer;"><span class="popup_action_icon"><svg width="14" height="16" viewBox="0 0 14 16" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M2.5 15.5C1.875 15.5 1.34375 15.2812 0.90625 14.8438C0.46875 14.4062 0.25 13.875 0.25 13.25V11H2.5V0.5H13.75V13.25C13.75 13.875 13.5312 14.4062 13.0938 14.8438C12.6562 15.2812 12.125 15.5 11.5 15.5H2.5ZM11.5 14C11.7125 14 11.8906 13.9281 12.0344 13.7844C12.1781 13.6406 12.25 13.4625 12.25 13.25V2H4V11H10.75V13.25C10.75 13.4625 10.8219 13.6406 10.9656 13.7844C11.1094 13.9281 11.2875 14 11.5 14ZM4.75 5.75V4.25H11.5V5.75H4.75ZM4.75 8V6.5H11.5V8H4.75ZM2.5 14H9.25V12.5H1.75V13.25C1.75 13.4625 1.82188 13.6406 1.96563 13.7844C2.10938 13.9281 2.2875 14 2.5 14ZM2.5 14H1.75H9.25H2.5Z" fill="#484848"/>
            </svg></span> ${act}</span>`;
        } else if (act === "edit") {
          buttonHTML = `<span class="pop_data edit-icon" style="cursor:pointer;"><span class="popup_action_icon"><svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M1.75 12.25H2.81875L10.15 4.91875L9.08125 3.85L1.75 11.1812V12.25ZM0.25 13.75V10.5625L10.15 0.68125C10.3 0.54375 10.4656 0.4375 10.6469 0.3625C10.8281 0.2875 11.0188 0.25 11.2188 0.25C11.4187 0.25 11.6125 0.2875 11.8 0.3625C11.9875 0.4375 12.15 0.55 12.2875 0.7L13.3188 1.75C13.4688 1.8875 13.5781 2.05 13.6469 2.2375C13.7156 2.425 13.75 2.6125 13.75 2.8C13.75 3 13.7156 3.19062 13.6469 3.37187C13.5781 3.55312 13.4688 3.71875 13.3188 3.86875L3.4375 13.75H0.25ZM9.60625 4.39375L9.08125 3.85L10.15 4.91875L9.60625 4.39375Z" fill="#484848"/>
              </svg></span> Edit Policy URL</span>`;
        } else if (act === "delete") {
          buttonHTML = `<span class="pop_data delete-icon" style="cursor:pointer;"><span class="popup_action_icon"><svg width="12" height="14" viewBox="0 0 12 14" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M2.25 13.75C1.8375 13.75 1.48438 13.6031 1.19062 13.3094C0.896875 13.0156 0.75 12.6625 0.75 12.25V2.5H0V1H3.75V0.25H8.25V1H12V2.5H11.25V12.25C11.25 12.6625 11.1031 13.0156 10.8094 13.3094C10.5156 13.6031 10.1625 13.75 9.75 13.75H2.25ZM9.75 2.5H2.25V12.25H9.75V2.5ZM3.75 10.75H5.25V4H3.75V10.75ZM6.75 10.75H8.25V4H6.75V10.75Z" fill="#484848"/>
            </svg></span> Remove Policy URL</span>`;
        } else if (act === "ADD JSON") {
          buttonHTML = `<span class="add-json-btn act_data pop_data " style="cursor: pointer;"><span class="popup_action_icon"><svg width="16" height="12" viewBox="0 0 16 12" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M9.5 12V10.5H11.75C11.9625 10.5 12.1406 10.4281 12.2844 10.2844C12.4281 10.1406 12.5 9.9625 12.5 9.75V8.25C12.5 7.775 12.6375 7.34375 12.9125 6.95625C13.1875 6.56875 13.55 6.29375 14 6.13125V5.86875C13.55 5.70625 13.1875 5.43125 12.9125 5.04375C12.6375 4.65625 12.5 4.225 12.5 3.75V2.25C12.5 2.0375 12.4281 1.85938 12.2844 1.71563C12.1406 1.57188 11.9625 1.5 11.75 1.5H9.5V0H11.75C12.375 0 12.9062 0.21875 13.3438 0.65625C13.7812 1.09375 14 1.625 14 2.25V3.75C14 3.9625 14.0719 4.14062 14.2156 4.28438C14.3594 4.42812 14.5375 4.5 14.75 4.5H15.5V7.5H14.75C14.5375 7.5 14.3594 7.57188 14.2156 7.71563C14.0719 7.85938 14 8.0375 14 8.25V9.75C14 10.375 13.7812 10.9062 13.3438 11.3438C12.9062 11.7812 12.375 12 11.75 12H9.5ZM4.25 12C3.625 12 3.09375 11.7812 2.65625 11.3438C2.21875 10.9062 2 10.375 2 9.75V8.25C2 8.0375 1.92813 7.85938 1.78437 7.71563C1.64062 7.57188 1.4625 7.5 1.25 7.5H0.5V4.5H1.25C1.4625 4.5 1.64062 4.42812 1.78437 4.28438C1.92813 4.14062 2 3.9625 2 3.75V2.25C2 1.625 2.21875 1.09375 2.65625 0.65625C3.09375 0.21875 3.625 0 4.25 0H6.5V1.5H4.25C4.0375 1.5 3.85938 1.57188 3.71562 1.71563C3.57187 1.85938 3.5 2.0375 3.5 2.25V3.75C3.5 4.225 3.3625 4.65625 3.0875 5.04375C2.8125 5.43125 2.45 5.70625 2 5.86875V6.13125C2.45 6.29375 2.8125 6.56875 3.0875 6.95625C3.3625 7.34375 3.5 7.775 3.5 8.25V9.75C3.5 9.9625 3.57187 10.1406 3.71562 10.2844C3.85938 10.4281 4.0375 10.5 4.25 10.5H6.5V12H4.25Z" fill="#484848"/>
              </svg></span> ${act}</span>`;
        } else {
          buttonHTML = `<span class="act_data pop_data" style="display:inline-block; margin-right: 10px;">${act}</span>`;
        }

        return buttonHTML;
      }).join('');

      var actionDiv = `<div class="action-btns-container">${actionBtns}</div>`;

      var threeDotsBtn = `<div class=" three-dots-btn" style="cursor: pointer;" title="More options">&#9679; &#9679; &#9679;</div>`;

      //$tr.append($('<td class="action_sec">').html(actionDiv + threeDotsBtn));

      var actionContent = `<div class="action_sec">${actionDiv}${threeDotsBtn}</div>`;
      $tr.append($('<td>').html(actionContent));

      $tbody.append($tr);
    });


    $tbody.on('click', '.add-json-btn', function () {
      $('#addJsonModal').fadeIn();
    });

    $tbody.on('click', '.allow-re-run-btn', function () {
      $('#re-run-testModal').fadeIn();
    });

    // Handle Edit Modal
    $tbody.on('click', '.edit-icon', function () {
      var $row = $(this).closest('tr');
      var policyHandlerId = $row.find('td:nth-child(1)').text();
      var policyURL = $row.find('td:nth-child(2)').text();
      var requestType = $row.find('td:nth-child(3)').text();

      $('#editPolicyHandlerId').val(policyHandlerId);
      $('#editPolicyURL').val(policyURL);
      $('#editRequestType').val(requestType);

      $('#editInterceptionPolicyModal').fadeIn();
    });

    // Handle Delete Modal
    $tbody.on('click', '.delete-icon', function () {
      var $row = $(this).closest('tr');
      var policyHandlerId = $row.find('td:nth-child(1)').text();

      $('#deletePolicyHandlerId').text(policyHandlerId);

      $('#deleteInterceptionPolicyModal').fadeIn();
    });

    // Handle on Boarding Data Info Slider
    $(document).on('click', '.onBoarding-info-btn', function () {
      $('#onBoardingInfo').addClass('active');

      // Close the modal
      $('#re-run-testModal').hide();
    });

    // Handle configure Endpoint form Slider
    $tbody.on('click', '.configure-form-btn', function () {
      $('#configureEndpoint').addClass('active');
    });

    // Handle Compose Policy Slider
    $tbody.on('click', '.compose-policy-btn', function () {
      $('#composePolicySlider').addClass('active');
    });



    // Handle Interception Info Slider
    $tbody.on('click', '.configure-unwrap-btn', function () {
      var $row = $(this).closest('tr');
      var policyHandlerId = $row.find('td:nth-child(1)').text();
      var policyURL = $row.find('td:nth-child(2)').text();
      var requestType = $row.find('td:nth-child(3)').text();
      var interceptionInfo = $(this).text();

      // Populate the slider with data
      $('#sliderPolicyHandlerId').text(policyHandlerId);
      $('#sliderPolicyURL').text(policyURL);
      $('#sliderRequestType').text(requestType);
      $('#sliderInterceptionDetails').text(interceptionInfo);

      // Show the new slider
      $('#interceptionInfoSlider').addClass('active');
    });


    // Close Slider
    $('.slider-close').on('click', function () {
      $('#onBoardingInfo').removeClass('active');
      $('#configureEndpoint').removeClass('active');
      $('#composePolicySlider').removeClass('active');
      $('#interceptionInfoSlider').removeClass('active');
    });

    // Close Slider when Clicking Outside
    $(window).on('click', function (e) {
      var $onBoardingInfoSlider = $('#onBoardingInfo');
      var $configureFormSlider = $('#configureEndpoint');
      var $composeSlider = $('#composePolicySlider');
      var $infoSlider = $('#interceptionInfoSlider');
      if (
        $onBoardingInfoSlider.hasClass('active') &&
        !$(e.target).closest('#onBoardingInfo').length &&
        !$(e.target).hasClass('onBoarding-info-btn')
      ) {
        $onBoardingInfoSlider.removeClass('active');
      }
      if (
        $configureFormSlider.hasClass('active') &&
        !$(e.target).closest('#configureEndpoint').length &&
        !$(e.target).hasClass('configure-form-btn')
      ) {
        $configureFormSlider.removeClass('active');
      }
      if (
        $composeSlider.hasClass('active') &&
        !$(e.target).closest('#composePolicySlider').length &&
        !$(e.target).hasClass('compose-policy-btn')
      ) {
        $composeSlider.removeClass('active');
      }
      if (
        $infoSlider.hasClass('active') &&
        !$(e.target).closest('#interceptionInfoSlider').length &&
        !$(e.target).hasClass('configure-unwrap-btn')
      ) {
        $infoSlider.removeClass('active');
      }
    });

    // Close Modal on Close Button
    $('.modal-close').on('click', function () {
      $(this).closest('.modal').fadeOut();
    });

    // Close Modal when Clicking Outside
    $(window).on('click', function (e) {
      if ($(e.target).hasClass('modal')) {
        $(e.target).fadeOut();
      }
    });
  });


/*
  //table array data for Encryption Key Configurations
  var encryptionKeyData = [
    {
      "encryptionModeId": "Enc_001",
      "encryptionMode": "AES",
      "encryptionInfo": "AES with Javax.crypto",
    },
    {
      "encryptionModeId": "Enc_002",
      "encryptionMode": "AES",
      "encryptionInfo": "AES with Javax.crypto",
    },
    {
      "encryptionModeId": "Enc_003",
      "encryptionMode": "AES",
      "encryptionInfo": "AES with Javax.crypto",
    },
    {
      "encryptionModeId": "Enc_004",
      "encryptionMode": "AES",
      "encryptionInfo": "AES with Javax.crypto",
    },
    {
      "encryptionModeId": "Enc_005",
      "encryptionMode": "AES",
      "encryptionInfo": "AES with Javax.crypto",
    },
    {
      "encryptionModeId": "Enc_006",
      "encryptionMode": "AES",
      "encryptionInfo": "AES with Javax.crypto",
    },
    {
      "encryptionModeId": "Enc_007",
      "encryptionMode": "AES",
      "encryptionInfo": "AES with Javax.crypto",
    },

  ];
  
  */
                       
    function getEncryptionModes(){
         var response;                             	
         var xhttp = new XMLHttpRequest();
          xhttp.onreadystatechange = function() {
           if (this.readyState == 4 && this.status == 200) {
            response=JSON.parse(this.responseText);                    	                                   	       
            }
         };
        xhttp.open("GET","EngineDataHandlerServlet?todo=getEncryptionModes",false);
        xhttp.send();
        return response;
      }

  $(document).ready(function () {
    var $tbody = $('.encryption_key_table_data');
    $tbody.empty();
    var encryptionKeyData=getEncryptionModes();
    
    encryptionKeyData.forEach(function (row) {
      var $tr = $('<tr>');
      $tr.append($('<td>').text(row.encryptionModeId));
      $tr.append($('<td>').text(row.encryptionMode));
      $tr.append($('<td>').html(`<button type="button" class="btn_primary btn_primary_btn" style="margin:2px 4px;">${row.encryptionInfo}</button>`));
      $tr.append(
        //  <i class="fa fa-edit edit-icon" style="cursor:pointer; margin-right:10px;" title="Edit"></i>
        // <i class="fa fa-trash delete-icon" style="cursor:pointer; margin-right:10px; color:#d9534f;" title="Delete"></i>
        $('<td>').html(`      

        <div class="action_icon">     
<span class="edit-icon" style="margin-bottom: -3px; cursor:pointer; margin-right:10px;" title="Edit"><svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M5.375 19H6.8L16.575 9.225L15.15 7.8L5.375 17.575V19ZM3.375 21V16.75L16.575 3.575C16.775 3.39167 16.9958 3.25 17.2375 3.15C17.4792 3.05 17.7333 3 18 3C18.2667 3 18.525 3.05 18.775 3.15C19.025 3.25 19.2417 3.4 19.425 3.6L20.8 5C21 5.18333 21.1458 5.4 21.2375 5.65C21.3292 5.9 21.375 6.15 21.375 6.4C21.375 6.66667 21.3292 6.92083 21.2375 7.1625C21.1458 7.40417 21 7.625 20.8 7.825L7.625 21H3.375ZM15.85 8.525L15.15 7.8L16.575 9.225L15.85 8.525Z" fill="#8D2BBC"/>
</svg></span>    
<span class="delete-icon" style="margin-bottom: -3px; cursor:pointer; margin-right:10px; title="Delete"><svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M7.375 21C6.825 21 6.35417 20.8042 5.9625 20.4125C5.57083 20.0208 5.375 19.55 5.375 19V6H4.375V4H9.375V3H15.375V4H20.375V6H19.375V19C19.375 19.55 19.1792 20.0208 18.7875 20.4125C18.3958 20.8042 17.925 21 17.375 21H7.375ZM17.375 6H7.375V19H17.375V6ZM9.375 17H11.375V8H9.375V17ZM13.375 17H15.375V8H13.375V17Z" fill="#BC2B3C"/>
</svg>
</span> 
      </div>
      `)
      );
      $tbody.append($tr);
    });

    // Open Edit Modal
    $tbody.on('click', '.edit-icon', function () {
      var $row = $(this).closest('tr');
      var encryptionModeId = $row.find('td:nth-child(1)').text();
      var encryptionMode = $row.find('td:nth-child(2)').text();
      var encryptionInfo = $row.find('td:nth-child(3)').text();

      $('#editEncryptionModeId').val(encryptionModeId);
      $('#editEncryptionMode').val(encryptionMode);
      $('#editEncryptionInfo').val(encryptionInfo);

      $('#editModal').fadeIn();
    });

    // Open Delete Modal
    $tbody.on('click', '.delete-icon', function () {
      var $row = $(this).closest('tr');
      var encryptionModeId = $row.find('td:nth-child(1)').text();

      $('#deleteEncryptionModeId').text(encryptionModeId);

      $('#deleteModal').fadeIn();
    });

    $('.modal-close').on('click', function () {
      $(this).closest('.modal').fadeOut();
    });

    $(window).on('click', function (e) {
      if ($(e.target).hasClass('modal')) {
        $(e.target).fadeOut();
      }
    });
  });



  //table array data for Encryption Key Configurations
  var encryptionKeyDataNew = [
    {
      "reportId": "OPTS14952801",
      "reportTime": "2025-07-11, 12:58:53",
      "agentName": "privaclave Agent/AUP4E3F20AA",
      "applicationURL": "nLearn/onboardingTestURL",
      "payloadKey": "idnt.drLicInfo.drivlic",
      "predictedField": "driverlicense_no",
      "fieldValue": "D5971685",
    },
    {
      "reportId": "OPTS14952801",
      "reportTime": "2025-07-11, 12:58:53",
      "agentName": "privaclave Agent/AUP4E3F20AA",
      "applicationURL": "nLearn/onboardingTestURL",
      "payloadKey": "idnt.drLicInfo.drivlic",
      "predictedField": "driverlicense_no",
      "fieldValue": "D5971685",
    },
    {
      "reportId": "OPTS14952801",
      "reportTime": "2025-07-11, 12:58:53",
      "agentName": "privaclave Agent/AUP4E3F20AA",
      "applicationURL": "nLearn/onboardingTestURL",
      "payloadKey": "idnt.drLicInfo.drivlic",
      "predictedField": "driverlicense_no",
      "fieldValue": "D5971685",
    },
    {
      "reportId": "OPTS14952801",
      "reportTime": "2025-07-11, 12:58:53",
      "agentName": "privaclave Agent/AUP4E3F20AA",
      "applicationURL": "nLearn/onboardingTestURL",
      "payloadKey": "idnt.drLicInfo.drivlic",
      "predictedField": "driverlicense_no",
      "fieldValue": "D5971685",
    },
    {
      "reportId": "OPTS14952801",
      "reportTime": "2025-07-11, 12:58:53",
      "agentName": "privaclave Agent/AUP4E3F20AA",
      "applicationURL": "nLearn/onboardingTestURL",
      "payloadKey": "idnt.drLicInfo.drivlic",
      "predictedField": "driverlicense_no",
      "fieldValue": "D5971685",
    },
    {
      "reportId": "OPTS14952801",
      "reportTime": "2025-07-11, 12:58:53",
      "agentName": "privaclave Agent/AUP4E3F20AA",
      "applicationURL": "nLearn/onboardingTestURL",
      "payloadKey": "idnt.drLicInfo.drivlic",
      "predictedField": "driverlicense_no",
      "fieldValue": "D5971685",
    },
    {
      "reportId": "OPTS14952801",
      "reportTime": "2025-07-11, 12:58:53",
      "agentName": "privaclave Agent/AUP4E3F20AA",
      "applicationURL": "nLearn/onboardingTestURL",
      "payloadKey": "idnt.drLicInfo.drivlic",
      "predictedField": "driverlicense_no",
      "fieldValue": "D5971685",
    },
    {
      "reportId": "OPTS14952801",
      "reportTime": "2025-07-11, 12:58:53",
      "agentName": "privaclave Agent/AUP4E3F20AA",
      "applicationURL": "nLearn/onboardingTestURL",
      "payloadKey": "idnt.drLicInfo.drivlic",
      "predictedField": "driverlicense_no",
      "fieldValue": "D5971685",
    },
  ];

  $(document).ready(function () {
    var $tbody = $('.encryption_key_table_dataNew');
    $tbody.empty();

    encryptionKeyDataNew.forEach(function (row) {
      var $tr = $('<tr>');
      $tr.append($('<td>').text(row.reportId));
      $tr.append($('<td>').text(row.reportTime));
      $tr.append($('<td>').text(row.agentName));
      $tr.append($('<td>').text(row.applicationURL));
      $tr.append($('<td>').text(row.payloadKey));
      $tr.append($('<td>').text(row.predictedField));
      $tr.append($('<td>').text(row.fieldValue));

      $tr.append(
        $('<td>').html(`    
      <div class="action_icon">  
      <button type="button" class="mark_optimize_button" style="margin:2px 4px; width: 165px;">Mark for Optimization</button>
      </div>
      `)
      );
      $tbody.append($tr);
    });

    // Add this after table is generated:
    $tbody.on('click', '.mark_optimize_button', function () {
      $(this)
        .removeClass('mark_optimize_button')
        .addClass('added_optimize_button')
        .text('Added for Optimization');
    });

    // Handle Start Optimization button (outside the table)
    $('.btn_purple_outline').on('click', function () {
      $('#optimizationSlider').addClass('active');
    });

    // Close slider when clicking on elements with .slider-close
    $('.slider-close').on('click', function () {
      $('#optimizationSlider').removeClass('active');
    });

    // Close slider if clicked outside of it
    $(document).on('click', function (event) {
      const $slider = $('#optimizationSlider');

      // If slider is open AND click is outside the slider AND not on any button that opens it
      if (
        $slider.hasClass('active') &&
        !$slider.is(event.target) &&
        $slider.has(event.target).length === 0 &&
        !$(event.target).is('.btn_purple_outline') &&
        !$(event.target).closest('.slider_optimize_btn').length
      ) {
        $slider.removeClass('active');
      }
    });

    // $('#optimizationSlider').on('click', function (e) {
    //   e.stopPropagation();
    // });


  });

  //table array data for optimizationSlider_data
  var optimizationSliderData = [
    {
      requestUrl: "onboardingTestURL",
      predictedField: "L46788756",
      groundTruth: "driverlicense_no",
      action: "Optimize"
    },
    {
      requestUrl: "onboardingTestURL",
      predictedField: "L46788756",
      groundTruth: "driverlicense_no",
      action: "In Progress"
    },
    {
      requestUrl: "onboardingTestURL",
      predictedField: "L46788756",
      groundTruth: "driverlicense_no",
      action: "Optimize"
    },
    {
      requestUrl: "onboardingTestURL",
      predictedField: "L46788756",
      groundTruth: "driverlicense_no",
      action: "Optimize"
    },
    {
      requestUrl: "onboardingTestURL",
      predictedField: "L46788756",
      groundTruth: "driverlicense_no",
      action: "Optimize"
    },
    {
      requestUrl: "onboardingTestURL",
      predictedField: "L46788756",
      groundTruth: "driverlicense_no",
      action: "In Progress"
    },
    {
      requestUrl: "onboardingTestURL",
      predictedField: "L46788756",
      groundTruth: "driverlicense_no",
      action: "Optimize"
    },
  ];

  $(document).ready(function () {
    var $tbody = $('.optimizationSlider_data');
    $tbody.empty();

    optimizationSliderData.forEach(function (row) {
      var $tr = $('<tr>');

      $tr.append($('<td>').text(row.requestUrl));
      $tr.append($('<td>').html(`<p>Driver License No</p><p><strong>${row.predictedField}</strong></p>`));

      // Encryption Mode: show select if value is "Select Mode"
      if (row.groundTruth === "driverlicense_no") {
        $tr.append($('<td>').html(`
        <select class="font12 encryption-mode-select corrected-select">
          <option value="Select Mode" selected>driverlicense_no</option>
          <option value="AES-256">driverlicense_no</option>          
        </select>
      `));
      } else {
        $tr.append($('<td>').text(row.encryptionMode));
      }

      // Add Action Button with dynamic text color
     
      var actionBtn = row.action === "In Progress" ? "added_optimize_button" : (row.action === "Optimize" ? "mark_optimize_button" : "inherit");

      $tr.append(
        $('<td>').html(
          `<div style="display: flex; justify-content: center;"><button type="button" class="${actionBtn}" style="width: 100%">${row.action}</button></div>`
        )
      );
      $tbody.append($tr);
    });
  });


  //table array data for Classification Fields
  var classificationData = [
    {
      "classificationFieldId": "Cls_001",
      "classificationTokeId": "Full Name",
      "classificationFieldName": "Full Name",
    },
    {
      "classificationFieldId": "Cls_002",
      "classificationTokeId": "Address",
      "classificationFieldName": "Address",
    },
    {
      "classificationFieldId": "Cls_003",
      "classificationTokeId": "Social Security Number",
      "classificationFieldName": "SSN",
    },
    {
      "classificationFieldId": "Cls_004",
      "classificationTokeId": "Full Name",
      "classificationFieldName": "Full Name",
    },
    {
      "classificationFieldId": "Cls_005",
      "classificationTokeId": "Address",
      "classificationFieldName": "Address",
    },
    {
      "classificationFieldId": "Cls_006",
      "classificationTokeId": "Social Security Number",
      "classificationFieldName": "SSN",
    },

  ];

  $(document).ready(function () {
    var $tbody = $('.classification_table_data');
    $tbody.empty();

    classificationData.forEach(function (row) {
      var $tr = $('<tr>');
      $tr.append($('<td>').text(row.classificationFieldId));
      $tr.append($('<td>').text(row.classificationTokeId));
      $tr.append($('<td>').html(`<button type="button" class="btn_primary btn_primary_btn" style="margin:2px 4px;">${row.classificationFieldName}</button>`));
      //  <i class="fa fa-edit edit-icon" style="cursor:pointer; margin-right:10px;" title="Edit"></i>
      //         <i class="fa fa-trash delete-icon" style="cursor:pointer; margin-right:10px; color:#d9534f;" title="Delete"></i>
      $tr.append(
        $('<td>').html(`
       
        <div class="action_icon">     
<span class="edit-icon" style="margin-bottom: -3px; cursor:pointer; margin-right:10px;" title="Edit"><svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M5.375 19H6.8L16.575 9.225L15.15 7.8L5.375 17.575V19ZM3.375 21V16.75L16.575 3.575C16.775 3.39167 16.9958 3.25 17.2375 3.15C17.4792 3.05 17.7333 3 18 3C18.2667 3 18.525 3.05 18.775 3.15C19.025 3.25 19.2417 3.4 19.425 3.6L20.8 5C21 5.18333 21.1458 5.4 21.2375 5.65C21.3292 5.9 21.375 6.15 21.375 6.4C21.375 6.66667 21.3292 6.92083 21.2375 7.1625C21.1458 7.40417 21 7.625 20.8 7.825L7.625 21H3.375ZM15.85 8.525L15.15 7.8L16.575 9.225L15.85 8.525Z" fill="#8D2BBC"/>
</svg></span>    
<span class="delete-icon" style="margin-bottom: -3px; cursor:pointer; margin-right:10px; title="Delete"><svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M7.375 21C6.825 21 6.35417 20.8042 5.9625 20.4125C5.57083 20.0208 5.375 19.55 5.375 19V6H4.375V4H9.375V3H15.375V4H20.375V6H19.375V19C19.375 19.55 19.1792 20.0208 18.7875 20.4125C18.3958 20.8042 17.925 21 17.375 21H7.375ZM17.375 6H7.375V19H17.375V6ZM9.375 17H11.375V8H9.375V17ZM13.375 17H15.375V8H13.375V17Z" fill="#BC2B3C"/>
</svg>
</span> 
      </div>
      `)
      );
      $tbody.append($tr);
    });

    // Open Edit Modal
    $tbody.on('click', '.edit-icon', function () {
      var $row = $(this).closest('tr');
      var fieldId = $row.find('td:nth-child(1)').text();
      var tokeId = $row.find('td:nth-child(2)').text();
      var fieldName = $row.find('td:nth-child(3)').text();

      $('#editFieldId').val(fieldId);
      $('#editTokeId').val(tokeId);
      $('#editFieldName').val(fieldName);

      $('#editModal').fadeIn();
    });

    // Open Delete Modal
    $tbody.on('click', '.delete-icon', function () {
      var $row = $(this).closest('tr');
      var fieldId = $row.find('td:nth-child(1)').text(); // Get the Classification Field Id

      // Update the delete modal content with the fieldId
      $('#deleteModal .font10').html(`Deleting “<strong>${fieldId}</strong>” will remove it from all policies and erase its history, are you sure you want to proceed?`);

      // Show the Delete Modal
      $('#deleteModal').fadeIn();
    });
  });


  //table array data for onBoarding_data_info
  var onBoardingData = [
    {
      "jsonKey": "prsnlinfo.key_1",
      "modelPrediction": {
        "Full Name": "Sheldon Harvey"
      },
      "correctedPrediction": ["Full Name"],
      "action": "Confirm",
    },
    {
      "jsonKey": "prsnlinfo.key_2",
      "modelPrediction": {
        "DOB": "1987-10-11"
      },
      "correctedPrediction": ["Dob"],
      "action": "Confirm",
    },
    {
      "jsonKey": "prsnlinfo.key_3",
      "modelPrediction": {
        "Gender": "Female"
      },
      "correctedPrediction": ["Gender", "Male", "Female"],
      "action": "Reject",
    },
    {
      "jsonKey": "prsnlinfo.key_4",
      "modelPrediction": {
        "Ethnicity": "American Indian or Alaska Native"
      },
      "correctedPrediction": ["Ethnicity"],
      "action": "Reject",
    },
    {
      "jsonKey": "prsnlinfo.key_5",
      "modelPrediction": {
        "Address": "Ohio, USA"
      },
      "correctedPrediction": ["Address"],
      "action": "Reject",
    },
    {
      "jsonKey": "prsnlinfo.key_6",
      "modelPrediction": {
        "Blood Group": "AB -ve"
      },
      "correctedPrediction": ["Blood Group"],
      "action": "Confirm",
    },
    {
      "jsonKey": "prsnlinfo.key_6",
      "modelPrediction": {
        "Tax Number": "2342425223"
      },
      "correctedPrediction": ["Tax Number"],
      "action": "Confirm",
    },
    {
      "jsonKey": "prsnlinfo.key_6",
      "modelPrediction": {
        "Mobile Number": "+1 (555) 123-4567"
      },
      "correctedPrediction": ["Mobile Number"],
      "action": "Confirm",
    },
    {
      "jsonKey": "prsnlinfo.key_6",
      "modelPrediction": {
        "Email": "sheldon12@gmail.com"
      },
      "correctedPrediction": ["Email"],
      "action": "Confirm",
    },
    {
      "jsonKey": "prsnlinfo.key_6",
      "modelPrediction": {
        "Company": "Privaclave"
      },
      "correctedPrediction": ["Company"],
      "action": "Confirm",
    },
    {
      "jsonKey": "prsnlinfo.key_6",
      "modelPrediction": {
        "Disability": "No"
      },
      "correctedPrediction": ["Disability"],
      "action": "Confirm",
    },

  ];

  $(document).ready(function () {

    var $tbody = $('.onBoarding_data_info');
    $tbody.empty();

    onBoardingData.forEach(function (row) {
      var $tr = $('<tr>');
      $tr.append($('<td>').text(row.jsonKey));
      var modelKey = Object.keys(row.modelPrediction)[0];
      var modelValue = row.modelPrediction[modelKey];
      $tr.append(
        $('<td>').html(`<p>${modelKey}</p><p><strong>${modelValue}</strong></p>`)
      );
      var selectHtml = '<select class="corrected-select" style="width: 100%;">';
      row.correctedPrediction.forEach(function (opt, idx) {
        selectHtml += `<option value="${opt}"${idx === 0 ? ' selected' : ''}>${opt}</option>`;
      });
      selectHtml += '</select>';
      $tr.append($('<td>').html(selectHtml));

      var actionColor = row.action === "Confirm" ? "#8D2BBC" : (row.action === "Reject" ? "#BC2B3C" : "inherit");
      var actionBtn = row.action === "Reject" ? "action_light_red" : (row.action === "Confirm" ? "action_light_purple" : "inherit");
      $tr.append($('<td>').html(`<button type="button" class="btn_protection ${actionBtn}" style="color:${actionColor};font-weight:bold;">${row.action}</button>`));

      $tbody.append($tr);
    });

  });

  //table array data for configure_endpoint_form
  var configureEndpointForm = [
    {
      "full_name": "full_name",
      "STRING": "STRING",
    },
    {
      "full_name": "full_name",
      "STRING": "STRING",
    },
    {
      "full_name": "full_name",
      "STRING": "STRING",
    },
    {
      "full_name": "full_name",
      "STRING": "STRING",
    },
    {
      "full_name": "full_name",
      "STRING": "STRING",
    },
    {
      "full_name": "full_name",
      "STRING": "STRING",
    },
    {
      "full_name": "full_name",
      "STRING": "STRING",
    },
  ];

  $(document).ready(function () {
    var $tbody = $('.configure_endpoint_form');
    $tbody.empty();

    configureEndpointForm.forEach(function (row) {
      var $tr = $('<tr>');
      $tr.append($('<td>').text(row.full_name));
      $tr.append($('<td>').text(row.STRING));
      $tr.append($('<td style="text-align: center;">').html(`<i class="fa fa-trash delete-icon" style="cursor:pointer; margin:2px 8px 2px 0; color:#d9534f;" title="Delete"></i>`));
      $tbody.append($tr);
    });
  });



  //table array data for policy_configurations
  var policyConfigurations = [
    {
      "postURL": "PatientRegisteration",
      "fieldEncryptionInfo": {
        "Field Name": "Genome Sequencing",
        "Protected With": "SHA-256",
        "Key Used": "SHA256_KEY1",
      },
      "searchParameter": "Mark as Searchable",
      "action": "Reset Action",
    },
    {
      "postURL": "PatientRegisteration",
      "fieldEncryptionInfo": {
        "Field Name": "Genome Sequencing",
        "Protected With": "SHA-256",
        "Key Used": "SHA256_KEY1",
      },
      "searchParameter": "Enter Searchable Name",
      "action": "Allow to Decrypt",
    },
    {
      "postURL": "PatientRegisteration",
      "fieldEncryptionInfo": {
        "Field Name": "Genome Sequencing",
        "Protected With": "SHA-256",
        "Key Used": "SHA256_KEY1",
      },
      "searchParameter": "Enter Searchable Name",
      "action": "Allow to Decrypt",
    },
    {
      "postURL": "PatientRegisteration",
      "fieldEncryptionInfo": {
        "Field Name": "Genome Sequencing",
        "Protected With": "SHA-256",
        "Key Used": "SHA256_KEY1",
      },
      "searchParameter": "Enter Searchable Name",
      "action": "Allow to Decrypt",
    },
    {
      "postURL": "PatientRegisteration",
      "fieldEncryptionInfo": {
        "Field Name": "Genome Sequencing",
        "Protected With": "SHA-256",
        "Key Used": "SHA256_KEY1",
      },
      "searchParameter": "Mark as Searchable",
      "action": "Reset Action",
    },
  ];

  $(document).ready(function () {
    var $tbody = $('.policy_configurations');
    $tbody.empty();

    policyConfigurations.forEach(function (row) {
      var $tr = $('<tr>');
      $tr.append($('<td>').text(row.postURL));

      var keys = Object.keys(row.fieldEncryptionInfo);
      var headerRow = '<div style="display:table-row;">';
      var valueRow = '<div style="display:table-row;">';
      keys.forEach(function (key) {
        headerRow += `<div style="display:table-cell; padding:2px 8px;">${key}</div>`;
        valueRow += `<div style="display:table-cell; font-weight:bold; padding:2px 8px;">${row.fieldEncryptionInfo[key]}</div>`;
      });
      headerRow += '</div>';
      valueRow += '</div>';

      var fieldEncryptionInfo = `
    <div style="display:table; width:100%;">
      ${headerRow}
      ${valueRow}
    </div>
  `;
      $tr.append($('<td>').html(fieldEncryptionInfo));

      if (row.searchParameter === "Enter Searchable Name") {
        $tr.append($('<td>').html(`<div class="search_parameter"><input type="text" class="search-input" placeholder="${row.searchParameter}" style="width: 100%;"></div>`));
      } else if (row.searchParameter === "Mark as Searchable") {
        $tr.append($('<td>').html(`
    <label style="display:flex;align-items:center;gap:6px;">
      <input type="checkbox" class="search-checkbox" style="margin:0;">
      <span>${row.searchParameter}</span>
    </label>
  `));
      } else {
        $tr.append($('<td>').text(row.searchParameter));
      }

      // Action color logic
      var actionColor = row.action === "Reset Action" ? "#BC2B3C" : (row.action === "Allow to Decrypt" ? "purple" : "inherit");
      var actionBtn = row.action === "Reset Action" ? "action_light_red" : (row.action === "Allow to Decrypt" ? "action_light_purple" : "inherit");
      $tr.append($('<td>').html(`<button type="button" class="btn_protection ${actionBtn}" style="color:${actionColor};font-weight:bold;">${row.action}</button>`));

      $tbody.append($tr);
    });
  });


  //table array data for configure_interception_policy
  var configureInterceptionPolicyData = [
    {
      fieldInfo: "*selected_parent_id_vid",
      type: "STRING",
      encryptionMode: "Select Mode",
      encryptionKey: "Select Key",
      classificationLevels: "Confidential",
      protectionStatus: "Protected",
      action: "Remove Protection"
    },
    {
      fieldInfo: "*selected_parent_id_vid",
      type: "STRING",
      encryptionMode: "Select Mode",
      encryptionKey: "Select Key",
      classificationLevels: "Internal",
      protectionStatus: "Not Protected",
      action: "Protect Now"
    },
    {
      fieldInfo: "*selected_parent_id_vid",
      type: "STRING",
      encryptionMode: "Select Mode",
      encryptionKey: "Select Key",
      classificationLevels: "Restricted",
      protectionStatus: "Protected",
      action: "Remove Protection"
    },
    {
      fieldInfo: "*selected_parent_id_vid",
      type: "STRING",
      encryptionMode: "Select Mode",
      encryptionKey: "Select Key",
      classificationLevels: "Public",
      protectionStatus: "Not Protected",
      action: "Protect Now"
    },
    {
      fieldInfo: "*selected_parent_id_vid",
      type: "STRING",
      encryptionMode: "Select Mode",
      encryptionKey: "Select Key",
      classificationLevels: "Confidential",
      protectionStatus: "Not Protected",
      action: "Protect Now"
    },
  ];

  $(document).ready(function () {
    var $tbody = $('.configure_interception_policy');
    $tbody.empty();

    configureInterceptionPolicyData.forEach(function (row) {
      var $tr = $('<tr>');

      $tr.append($('<td>').text(row.fieldInfo));
      $tr.append($('<td>').text(row.type));

      // Encryption Mode: show select if value is "Select Mode"
      if (row.encryptionMode === "Select Mode") {
        $tr.append($('<td>').html(`
        <select class="font10 encryption-mode-select corrected-select" style="width:100%;">
          <option value="Select Mode" selected>Select Mode</option>
          <option value="AES-256">AES-256</option>
          <option value="SHA-256">SHA-256</option>
          <option value="RSA-2048">RSA-2048</option>
        </select>
      `));
      } else {
        $tr.append($('<td>').text(row.encryptionMode));
      }

      // Encryption Key: show select if value is "Select Key"
      if (row.encryptionKey === "Select Key") {
        $tr.append($('<td>').html(`
        <select class="font10 encryption-key-select corrected-select" style="width:100%;">
          <option value="Select Key" selected>Select Key</option>
          <option value="KEY_001">KEY_001</option>
          <option value="KEY_002">KEY_002</option>
          <option value="KEY_003">KEY_003</option>
        </select>
      `));
      } else {
        $tr.append($('<td>').text(row.encryptionKey));
      }
      // Classification Levels with dynamic button color
      var classificationClass;
      if (row.classificationLevels === "Confidential") {
        classificationClass = "btn_orange";
      } else if (row.classificationLevels === "Internal") {
        classificationClass = "btn_blue";
      } else if (row.classificationLevels === "Restricted") {
        classificationClass = "btn_red";
      } else if (row.classificationLevels === "Public") {
        classificationClass = "btn_green";
      }
      $tr.append(
        $('<td>').html(
          `<button type="button" class="btn_classification ${classificationClass}">${row.classificationLevels}</button>`
        )
      );
      // Add Protection Status with dynamic button color
      var protectionClass;
      if (row.protectionStatus === "Protected") {
        protectionClass = "btn_light_blue";
      } else if (row.protectionStatus === "Not Protected") {
        protectionClass = "btn_light_red";
      }
      $tr.append(
        $('<td>').html(
          `<button type="button" class="btn_protection ${protectionClass}">&#10004; ${row.protectionStatus}</button>`
        )
      );
      // Add Action Button with dynamic text color
      var actionStyle;
      if (row.action === "Protect Now") {
        actionStyle = "color: purple;";
      } else if (row.action === "Remove Protection") {
        actionStyle = "color: #BC2B3C;";
      }

      var actionBtn = row.action === "Remove Protection" ? "action_light_red" : (row.action === "Protect Now" ? "action_light_purple" : "inherit");

      $tr.append(
        $('<td>').html(
          `<button type="button" class="btn_protection ${actionBtn}" style="${actionStyle}">${row.action}</button>`
        )
      );
      $tbody.append($tr);
    });
  });




  ///////dashboard Notification right slider/////
  $(document).ready(function () {
    // Open the right slider on notification button click
    $('.notifications_btn').on('click', function () {
      $('#dashboardNotification').addClass('active');
    });

    // Close the slider when clicking the close button
    $('#dashboardNotification .slider-close').on('click', function () {
      $('#dashboardNotification').removeClass('active');
    });

    // Optional: Close the slider when clicking outside of it
    $(window).on('click', function (e) {
      var $slider = $('#dashboardNotification');
      if (
        $slider.hasClass('active') &&
        !$(e.target).closest('#dashboardNotification').length &&
        !$(e.target).hasClass('notifications_btn') &&
        !$(e.target).closest('.notifications_btn').length
      ) {
        $slider.removeClass('active');
      }
    });
  });

  var dashboardNotificationData = [
    {
      "notiFicData": "Unauthorized data access detected (Salesforce Integration). Immediate action required.",
      "notiFic": "Severe",
    },
    {
      "notiFicData": "Unauthorized data access detected (Salesforce Integration). Immediate action required.",
      "notiFic": "Warning",
    },
    {
      "notiFicData": "Unauthorized data access detected (Salesforce Integration). Immediate action required.",
      "notiFic": "Warning",
    },
    {
      "notiFicData": "Unauthorized data access detected (Salesforce Integration). Immediate action required.",
      "notiFic": "Success",
    },
    {
      "notiFicData": "Unauthorized data access detected (Salesforce Integration). Immediate action required.",
      "notiFic": "Success",
    },
    {
      "notiFicData": "Unauthorized data access detected (Salesforce Integration). Immediate action required.",
      "notiFic": "Success",
    },
    {
      "notiFicData": "Unauthorized data access detected (Salesforce Integration). Immediate action required.",
      "notiFic": "Warning",
    },

  ];
  $(document).ready(function () {
    var $container = $('.notification_data');
    $container.empty();

    dashboardNotificationData.forEach(function (item) {
      var colorClass = '';
      if (item.notiFic === 'Severe') colorClass = 'noti-severe';
      else if (item.notiFic === 'Warning') colorClass = 'noti-warning';
      else if (item.notiFic === 'Success') colorClass = 'noti-success';

      var html = `
      <div class="notification_item" style="margin-bottom:12px; padding:12px; border-radius:6px; background:#f9f9f9;">
        <div style="font-size:12px; margin-bottom:4px;">${item.notiFicData}</div>
        <div class="noti_type ${colorClass}" style="font-size:12px; font-weight:bold;"><i class="fa fa-warning"></i> ${item.notiFic}</div>
      </div>
    `;
      $container.append(html);
    });
  });




  // Show modal on button click
  $(document).ready(function () {
    $('.add-new').on('click', function () {
      $('#addClassificationModal').fadeIn();
    });
    $('.modal-close').on('click', function () {
      $(this).closest('.modal').fadeOut();
    });
    $(window).on('click', function (e) {
      if ($(e.target).hasClass('modal')) {
        $(e.target).fadeOut();
      }
    });
  });

});


////graph chart and pie chart 1 2 and 3  ////

$(document).ready(function () {
  function renderChart(segments, chartId, tooltipId, total) {
    const radius = 85;
    const circumference = 2 * Math.PI * radius;
    let offset = 0;

    Object.keys(segments).forEach(id => {
      const seg = segments[id];
      const percent = seg.value / total;
      const length = percent * circumference;

      $('#' + id)
        .attr("stroke-dasharray", `${length} ${circumference}`)
        .attr("stroke-dashoffset", offset)
        .css("stroke", seg.color);

      offset -= length;
    });

    const $tooltip = $("#" + tooltipId);
    $(`#${chartId} circle`).on("mousemove", function (e) {
      const id = $(this).attr("id");
      const data = segments[id];
      if (!data) return;
      const percent = Math.round((data.value / total) * 100);

      const parentOffset = $(`#${chartId}`).offset();
      const relX = e.pageX - parentOffset.left;
      const relY = e.pageY - parentOffset.top;

      $tooltip
        .html(`<strong>${data.label}</strong><br>${(data.value / 1000).toFixed(1)}K <span style="background:#EAF3FF;padding:2px 6px;border-radius:4px;font-weight:bold;">${percent}%</span>`)
        .css({ top: relY - 30, left: relX + 10 })
        .fadeIn(150);
    }).on("mouseleave", () => $tooltip.fadeOut(100));
  }

  renderChart({ piiData: { label: "PII Data Intercepted", value: 320000, color: "#3974C2" }, phiData: { label: "PHI Data Intercepted", value: 480000, color: "#F2D8CC" } }, "comparisonDonutChart", "comparisonTooltip", 800000);
  renderChart({ internal: { label: "Internal", value: 72000, color: "#3974C2" }, confidential: { label: "Confidential Data", value: 336000, color: "#F4B942" }, restricted: { label: "Restricted", value: 72000, color: "#D04E4E" } }, "donutChart", "phiTooltip", 480000);
  renderChart({ publicPii: { label: "Public", value: 96000, color: "#34A853" }, internalPii: { label: "Internal", value: 67200, color: "#3974C2" }, confidentialPii: { label: "Confidential Data", value: 76800, color: "#F4B942" }, restrictedPii: { label: "Restricted", value: 80000, color: "#D04E4E" } }, "piiDonutChart", "piiTooltip", 320000);

  // Render bar chart
  const data = [
    { label: 'AWS API Gateways', value: 880000, color: '#2c7a7b', intercepted: 345370, classified: 555000, encrypted: 350000 },
    { label: 'S3 Bucket', value: 700000, color: '#f2c94c', intercepted: 280000, classified: 420000, encrypted: 310000 },
    { label: 'Azure APIM', value: 600000, color: '#bb00aa', intercepted: 250000, classified: 360000, encrypted: 270000 },
    { label: 'AWS Kinese', value: 500000, color: '#e76f51', intercepted: 345370, classified: 555000, encrypted: 350000 },
    { label: 'AWS Glue', value: 380000, color: '#2a78c5', intercepted: 180000, classified: 250000, encrypted: 150000 },
    { label: 'Google Cloud', value: 950000, color: '#a259d1', intercepted: 480000, classified: 700000, encrypted: 500000 },
    { label: 'Google Pub-Sub', value: 820000, color: '#f4c6b8', intercepted: 420000, classified: 600000, encrypted: 420000 },
    { label: 'Azure Storage', value: 870000, color: '#d66752', intercepted: 460000, classified: 620000, encrypted: 430000 }
  ];

  const $chart = $('#barChart');
  const $tooltip = $('#tooltip');
  const maxHeight = 220;
  const maxValue = 1000000;

  data.forEach(item => {
    const height = (item.value / maxValue) * maxHeight;
    const $barWrapper = $('<div class="bar-wrapper"></div>');
    const $bar = $('<div class="bar"></div>').css({ height: `${height}px`, backgroundColor: item.color });

    $bar.on('mouseenter', function () {
      const offset = $(this).offset();
      $tooltip.html(`
            <div><strong>Intercepted Data</strong><br>${(item.intercepted / 1000).toFixed(1)}K</div>
            <div>Classified Data<br>${(item.classified / 1000).toFixed(1)}K</div>
            <div>Encrypted Data<br>${(item.encrypted / 1000).toFixed(1)}K</div>
          `).css({ top: offset.top - 90, left: offset.left - 30 }).fadeIn(150);
    }).on('mouseleave', function () {
      $tooltip.fadeOut(100);
    });

    $barWrapper.append($bar);
    $barWrapper.append(`<div class="label_name">${item.label}</div>`);
    $chart.append($barWrapper);
  });
});


///////////heatmap////////

$(function () {
  const days = ['M', 'T', 'W', 'TH', 'F'];
  const $heatmap = $('#heatmap');
  const $hourLabels = $('#hour-labels');

  days.forEach(day => {
    $heatmap.append(`<div class="day-label" style="grid-row: span 5">${day}</div>`);

    for (let week = 0; week < 5; week++) {
      for (let i = 0; i < 72; i++) {
        const value = Math.floor(Math.random() * 100);
        let color = '#f4f0ff';

        if (value > 80) color = '#8a5ce7';
        else if (value > 60) color = '#a684ef';
        else if (value > 40) color = '#c6b2f4';
        else if (value > 20) color = '#e1d4fa';

        $heatmap.append(`<div class="cell" style="background-color:${color}" title="${day}, week ${week + 1}, hour block ${i + 1} = ${value}"></div>`);
      }
    }
  });

  // Hour labels
  $hourLabels.append('<span></span>');
  for (let i = 0; i < 72; i++) {
    if (i % 3 === 0) {
      const hour = String(i / 3).padStart(2, '0');
      $hourLabels.append(`<span>${hour}</span>`);
    } else {
      $hourLabels.append(`<span></span>`);
    }
  }
});







