package com.cockpit.util;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Set;

import com.cockpit.model.*;
public class PageMenuManager {
  
	public PageMenuManager() {
		
	}
	public static void main(String[] args) {
		// TODO : Menu Testcase
		ArrayList<PageMenuBean> list= new PageMenuManager().getListofMenu("functionalPage");
		for(PageMenuBean bean : list) {
			System.out.println(bean.getPageName()+":"+bean.getPageLink());
		}
	}
	
	public ArrayList<PageMenuBean> getListofMenu(String menu_for){
		ArrayList<PageMenuBean> list = new ArrayList<>();
        Properties properties = new Properties();

        try (InputStream input = PageMenuManager.class.getResourceAsStream(menu_for+".properties")) {
            if (input == null) {
                System.out.println("Property file not found!");
                return list;
            }

            properties.load(input);
            Set<String> keys = properties.stringPropertyNames();

            for (String key : keys) {
                String value = properties.getProperty(key);
                PageMenuBean bean=new PageMenuBean();
                bean.setPageLink(key);
                bean.setPageName(value);
                list.add(bean);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        
        return list;

	}
}
