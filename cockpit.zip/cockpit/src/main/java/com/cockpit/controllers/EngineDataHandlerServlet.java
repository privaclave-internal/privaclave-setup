package com.cockpit.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cockpit.model.EncryptionModeModel;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class EngineDataHandlerServlet
 */
public class EngineDataHandlerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EngineDataHandlerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("application/json");
		PrintWriter out=response.getWriter();
		String todo=request.getParameter("todo");
		
		// TODO :  get List of Encryption Modes FOR encryptionModes.jsp -> tbody : encryption_key_table_data
		if(todo.equals("getEncryptionModes")) {
			// Sample backend Data
			   ArrayList<EncryptionModeModel> encModeList=new ArrayList<EncryptionModeModel>();
			   int noOfSampleRecords=7;
			   for(int i=0;i<noOfSampleRecords;i++) {
				   EncryptionModeModel bean=new EncryptionModeModel();
				   bean.setEncryptionModeId("Enc_00"+(i+1));
				   if(i==1) {
				   bean.setEncryptionMode("FFX");
				   bean.setEncryptionInfo("Format Preserving Encryption (FPE)");
				   }else {
					   bean.setEncryptionMode("AES");
					   bean.setEncryptionInfo("AES 256 Encryption");
				   }
				   encModeList.add(bean);
			   }
			   ObjectMapper mapper=new ObjectMapper();
			   String encModeListJsonData=mapper.writeValueAsString(encModeList);
			   out.print(encModeListJsonData);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String todo=request.getParameter("todo");
		
		// TODO :  ENCRYPTION KEY FROM encryptionModes.jsp -> form : save_Encryption_info
		if(todo.equals("addEncryptionMode")) {
			String encryption_type_code=request.getParameter("encryption_type_code");
			String encryption_key=request.getParameter("encryption_key").trim();
			
			out.print("Form Submitted to Controller with following data \n Encryption Mode "+encryption_type_code+" -> Value : "+encryption_key);
			
		}
	}

}
