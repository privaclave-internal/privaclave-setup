package com.cockpit.model;

public class PageMenuBean {
  private String pageLink,pageName;

public String getPageLink() {
	return pageLink;
}

public void setPageLink(String pageLink) {
	this.pageLink = pageLink;
}

public String getPageName() {
	return pageName;
}

public void setPageName(String pageName) {
	this.pageName = pageName;
}
}
