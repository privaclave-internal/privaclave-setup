package com.cockpit.model;

public class EncryptionModeModel {
 private String encryptionModeId,encryptionMode,encryptionInfo,encryptionModeStatus,encryptionKey;

public String getEncryptionModeId() {
	return encryptionModeId;
}

public void setEncryptionModeId(String encryptionModeId) {
	this.encryptionModeId = encryptionModeId;
}

public String getEncryptionModeStatus() {
	return encryptionModeStatus;
}

public void setEncryptionModeStatus(String encryptionModeStatus) {
	this.encryptionModeStatus = encryptionModeStatus;
}

public String getEncryptionInfo() {
	return encryptionInfo;
}

public void setEncryptionInfo(String encryptionInfo) {
	this.encryptionInfo = encryptionInfo;
}

public String getEncryptionMode() {
	return encryptionMode;
}

public void setEncryptionMode(String encryptionMode) {
	this.encryptionMode = encryptionMode;
}

public String getEncryptionKey() {
	return encryptionKey;
}

public void setEncryptionKey(String encryptionKey) {
	this.encryptionKey = encryptionKey;
}

 
}
