#!/bin/bash

# Log file for debugging
LOGFILE="install_mariadb.log"
exec > >(tee -i $LOGFILE)
exec 2>&1

# Stop MariaDB if running
sudo systemctl stop mariadb

# Remove MariaDB packages and data
sudo yum remove -y MariaDB-server MariaDB-client
sudo rm -rf /var/lib/mysql

# Remove MariaDB configuration files
sudo rm -rf /etc/my.cnf /etc/my.cnf.d /etc/yum.repos.d/MariaDB.repo

# Install MariaDB using default repository
echo "Installing MariaDB..."
sudo yum install -y mariadb-server mariadb

# Start and enable MariaDB
echo "Starting and enabling MariaDB..."
sudo systemctl start mariadb
sudo systemctl enable mariadb

# Create sample database and user
echo "Creating sample database and user..."
sudo mysql -u root <<EOF
CREATE DATABASE sampledb;
CREATE USER 'sampleuser'@'localhost' IDENTIFIED BY 'sample_password';
GRANT ALL PRIVILEGES ON sampledb.* TO 'sampleuser'@'localhost';
FLUSH PRIVILEGES;

USE sampledb;
CREATE TABLE customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO customers (name, email) VALUES ('John Doe', 'john.doe@example.com');
INSERT INTO customers (name, email) VALUES ('Jane Smith', 'jane.smith@example.com');
EOF

# Optional: Install and start firewalld
echo "Installing and starting firewalld..."
sudo yum install firewalld -y
sudo systemctl start firewalld
sudo systemctl enable firewalld

# Optional: Configure firewall for remote access
echo "Configuring firewall for remote access..."
sudo firewall-cmd --permanent --zone=public --add-port=3306/tcp
sudo firewall-cmd --reload

# Optional: Configure MariaDB for remote access
echo "Configuring MariaDB for remote access..."
sudo bash -c 'echo -e "[mysqld]\nbind-address=0.0.0.0" >> /etc/my.cnf'
sudo systemctl restart mariadb

echo "MariaDB installation and configuration complete."
