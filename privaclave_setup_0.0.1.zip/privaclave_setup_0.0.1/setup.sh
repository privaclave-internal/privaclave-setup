#!/bin/bash

# Stop the current Tomcat service if it exists
sudo systemctl stop tomcat 2>/dev/null

# Disable the Tomcat service if it exists
sudo systemctl disable tomcat 2>/dev/null

# Check if Java is already installed
if ! java -version &>/dev/null; then
    echo "Java is not installed. Proceeding with installation."
    sudo yum install -y java-1.8.0-openjdk
    # Verify JDK Installation
    java -version
else
    echo "Java is already installed. Skipping installation."
fi

# Check if MariaDB Client is already installed
if ! mariadb --version &>/dev/null; then
    echo "MariaDB Client is not installed. Proceeding with installation."
    sudo yum install -y mariadb
    # Verify MariaDB Installation
    mariadb --version
else
    echo "MariaDB Client is already installed. Skipping installation."
fi

# Install wget (if not already installed)
sudo yum install -y wget

# Set SELinux to permissive mode to avoid permission issues
if [ "$(getenforce)" != "Permissive" ]; then
    echo "Setting SELinux to permissive mode."
    sudo setenforce 0
fi

# Check if the Tomcat directory exists
if [ ! -d "/opt/tomcat" ]; then
    echo "Tomcat directory does not exist. Proceeding with download and installation."

    # Download and install Tomcat 9.0.91
    TOMCAT_VERSION=9.0.91
    wget https://dlcdn.apache.org/tomcat/tomcat-9/v$TOMCAT_VERSION/bin/apache-tomcat-$TOMCAT_VERSION.tar.gz
    tar -xzf apache-tomcat-$TOMCAT_VERSION.tar.gz
    sudo mv apache-tomcat-$TOMCAT_VERSION /opt/tomcat

    # Create tomcatgroup if it doesn't exist
    if ! grep -q '^tomcatgroup:' /etc/group; then
        sudo groupadd tomcatgroup
    fi

    # Create tomcatuser if it doesn't exist
    if ! id -u tomcatuser &>/dev/null; then
        sudo useradd -m -s /bin/bash -g tomcatgroup tomcatuser
        echo 'tomcatuser:tomcatpaswd' | sudo chpasswd
    fi

    # Set permissions and ownership for Tomcat
    sudo chown -R tomcatuser:tomcatgroup /opt/tomcat
    sudo chmod -R 755 /opt/tomcat
    sudo chmod +x /opt/tomcat/bin/*.sh

    # Ensure correct shebang in startup.sh
    sudo sed -i '1s|^.*$|#!/bin/bash|' /opt/tomcat/bin/startup.sh
    sudo dos2unix /opt/tomcat/bin/startup.sh

    # Create systemd service file for Tomcat
    sudo tee /etc/systemd/system/tomcat.service > /dev/null <<EOT
[Unit]
Description=Apache Tomcat Web Application Container
After=network.target

[Service]
Type=forking

Environment=JAVA_HOME=/usr/lib/jvm/jre-1.8.0-openjdk
Environment=CATALINA_PID=/opt/tomcat/temp/tomcat.pid
Environment=CATALINA_HOME=/opt/tomcat
Environment=CATALINA_BASE=/opt/tomcat
Environment="CATALINA_OPTS=-Xms512M -Xmx1024M -server -XX:+UseParallelGC"
Environment="JAVA_OPTS=-Djava.awt.headless=true -Djava.security.egd=file:/dev/./urandom"

ExecStart=/opt/tomcat/bin/startup.sh
ExecStop=/opt/tomcat/bin/shutdown.sh

User=tomcatuser
Group=tomcatgroup

[Install]
WantedBy=multi-user.target
EOT

    # Reload systemd to apply the new service file
    sudo systemctl daemon-reload

    # Enable and start the Tomcat service
    sudo systemctl enable tomcat
    sudo systemctl start tomcat

else
    echo "Tomcat directory exists. Skipping download and installation."

    # Ensure the permissions and ownership are correct
    sudo chown -R tomcatuser:tomcatgroup /opt/tomcat
    sudo chmod -R 755 /opt/tomcat
    sudo chmod +x /opt/tomcat/bin/*.sh

    # Ensure correct shebang in startup.sh
    sudo sed -i '1s|^.*$|#!/bin/bash|' /opt/tomcat/bin/startup.sh
    sudo dos2unix /opt/tomcat/bin/startup.sh

    # Ensure the systemd service file exists
    if [ ! -f /etc/systemd/system/tomcat.service ]; then
        # Create systemd service file for Tomcat
        sudo tee /etc/systemd/system/tomcat.service > /dev/null <<EOT
[Unit]
Description=Apache Tomcat Web Application Container
After=network.target

[Service]
Type=forking

Environment=JAVA_HOME=/usr/lib/jvm/jre-1.8.0-openjdk
Environment=CATALINA_PID=/opt/tomcat/temp/tomcat.pid
Environment=CATALINA_HOME=/opt/tomcat
Environment=CATALINA_BASE=/opt/tomcat
Environment="CATALINA_OPTS=-Xms512M -Xmx1024M -server -XX:+UseParallelGC"
Environment="JAVA_OPTS=-Djava.awt.headless=true -Djava.security.egd=file:/dev/./urandom"

ExecStart=/opt/tomcat/bin/startup.sh
ExecStop=/opt/tomcat/bin/shutdown.sh

User=tomcatuser
Group=tomcatgroup

[Install]
WantedBy=multi-user.target
EOT

        # Reload systemd to apply the new service file
        sudo systemctl daemon-reload
    fi

    # Ensure Tomcat service is enabled and started
    sudo systemctl enable tomcat
    sudo systemctl start tomcat
fi

# Verify Tomcat Installation and Status
sudo systemctl status tomcat

# Print detailed journal log
sudo journalctl -xeu tomcat.service

# Optionally, restore SELinux to enforcing mode
# sudo setenforce 1
